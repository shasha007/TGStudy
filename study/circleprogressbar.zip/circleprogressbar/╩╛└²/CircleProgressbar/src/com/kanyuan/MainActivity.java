package com.kanyuan;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;

import com.kanyuan.circleprogressbar.CircleProgressbar;
import com.kanyuan.circleprogressbar.R;

public class MainActivity extends Activity {
    private CircleProgressbar circleProgressbar;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.main);
		
		this.circleProgressbar = (CircleProgressbar)this.findViewById(R.id.circleProgressbar);
		//this.circleProgressbar.setTextVisibility(false);//不显示文字
	}

	/**
	 * 模拟进度
	 */
	public void start(View view){
		final Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				int progress = (Integer)msg.obj;
				circleProgressbar.setPercent(progress);
			}			
		};
		Thread thread = new Thread(){
			@Override
			public void run() {
				int progress = 0;
				try {
					while(progress <= 100){
						Message msg = new Message();
						msg.obj = progress;
						handler.sendMessage(msg);
						Thread.sleep(1000);
						progress += 5;
					}					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}				
			}			
		};
		thread.start();
	}
}
